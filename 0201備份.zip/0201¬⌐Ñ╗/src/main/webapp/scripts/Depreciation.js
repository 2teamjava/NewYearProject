function rate(New,Old,Life,Month){
    return New-((New-Old)*Month)/Life
}
function price(Cost,Life,PurchaseTime,Start,End){
    var New=1.5;
    var Old=0.7;
    var money=0;
    for(var Month=0;Month<End-Start;Month++){

    }
}